@extends('master')
@section('content')
<div class="contact">
        <div class="con2" style="font-family: cursive">
            <h3>CONTACT ON </h3>
            <a href="#">Twitter</a>&nbsp;&nbsp;
            <a href="#">Linkedin</a>&nbsp;&nbsp;
            <a href="#">Facebook</a>&nbsp;&nbsp;
            <a href="#">Instagram</a>&nbsp;&nbsp;

            <h3> <br> GMAIL ID : </h3>
            <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.dhruv@gmail.com</h3>
            <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.himanshu@gmail.com</h3>
            <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.divyesh@gmail.com</h3>
        </div>
</div>

@endsection