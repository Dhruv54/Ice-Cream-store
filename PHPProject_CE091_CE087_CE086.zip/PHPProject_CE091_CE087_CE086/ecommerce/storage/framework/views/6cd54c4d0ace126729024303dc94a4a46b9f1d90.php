
<?php $__env->startSection('content'); ?>
<div class="back">
<div class="container custom-login" style="font-family: cursive;color:darkcyan">
    <h3>PROJECT NAME : ONLINE ICE-CREAM STORE</h3><br>
    <h3>TOTAL GROUP MEMBERS : 3</h3><br>
    <h3>GROUP MEMBERS NAME : </h3>
    <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.DHRUV PATEL (CE091)</h3>
    <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2.HIMANSHU PARMAR (CE087)</h3>
    <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3.DIVYESH PARMAR (CE086)</h3>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/aboutus.blade.php ENDPATH**/ ?>