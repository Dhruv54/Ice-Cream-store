<?php
use App\Http\Controllers\ProductController;
$total=0;
if(Session::has('user'))
{
    $total= ProductController::cartItem();
}

?>

<?php $__env->startSection("content"); ?>

<?php if($total==0): ?>
    <h1 style="padding-left: 500px;padding-top:50px;padding-bottom:50px">Empty Cart!!!</h1>
    
<?php else: ?>

<div style="padding: 20px">
    <h4>Result for products</h4><br>
    <a  class="btn btn-success" href="ordernow">Order Now</a><br><br>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <a href="detail/<?php echo e($item->id); ?>">
                <img class="trending-img" src="<?php echo e($item->gallery); ?>" width="250px">
            </a><br><br>
        </div>
        <div>
            <h3><?php echo e($item->name); ?></h3>
            <h4>Rs.<?php echo e($item->price); ?></h4><br>
        </div>
        <div>
            <a href="/removecart/<?php echo e($item->cart_id); ?>" class="btn btn-warning">Remove to Cart</a>
        </div><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div>
        <a  class="btn btn-success" href="ordernow">Order Now</a><br>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/cartlist.blade.php ENDPATH**/ ?>