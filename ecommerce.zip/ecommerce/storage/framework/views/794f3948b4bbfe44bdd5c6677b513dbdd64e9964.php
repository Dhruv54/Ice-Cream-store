
<?php $__env->startSection("content"); ?>


<div style="padding: 30px">
    <h4>MY ORDERS</h4><br>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <div style="padding: 20px">
            <a href="detail/<?php echo e($item->id); ?>">
                <img class="trending-img" src="<?php echo e($item->gallery); ?>" width="200px">
            </a>
        </div><br>
        <div class="custom-product">
            <div class="col-sm-10">
            <table>
            <tr>
                <td>Product Name</td>
                <td>: <?php echo e($item->name); ?></td>
            <tr>
            <tr>
                <td>Delivery Status</td>
                <td>: <?php echo e($item->status); ?></td>
            </tr>
            <tr>
                <td>Address</td>
                <td>: <?php echo e($item->address); ?></td>
            </tr>
            <tr>
                <td>Payment Status</td>
                <td>: <?php echo e($item->payment_status); ?></td>
            </tr>
            <tr>
                <td>Payment Method</td>
                <td>: <?php echo e($item->payment_method); ?></td>
            </tr>
        <table>
            </div>
        </div><br>
    </div>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/myorders.blade.php ENDPATH**/ ?>