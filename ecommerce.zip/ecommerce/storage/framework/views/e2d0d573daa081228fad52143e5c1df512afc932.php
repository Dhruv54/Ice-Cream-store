
<?php $__env->startSection('content'); ?>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="main">
                    <a href="detail/<?php echo e($item['id']); ?>">
                        <div class="maindiv">
                          <img src="<?php echo e($item['gallery']); ?>" width="30%">
                            <div class="desc"  style="color: black;">
                              <h6 style="font-weight: 600"><?php echo e($item['name']); ?></h6>
                              <h6 style="font-weight: 400">price Rs:<?php echo e($item['price']); ?></h6>
                          </div>
                        </div>
                    </a>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/product.blade.php ENDPATH**/ ?>