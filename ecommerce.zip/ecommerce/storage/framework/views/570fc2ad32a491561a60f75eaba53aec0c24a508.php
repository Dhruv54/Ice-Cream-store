
<?php $__env->startSection('content'); ?>
<div class="container" style="padding: 10px">
    <div class="row">
        <div class="col-sm-6">
            <img class="detail-img" src="<?php echo e($product['gallery']); ?>">
        </div>
        <div class="col-sm-6">
            <br>
            <h3><?php echo e($product['name']); ?></h3>
            <h4><?php echo e($product['category']); ?></h4>
            <h3>Rs.<?php echo e($product['price']); ?></h3><br><br>
            <?php if(Session::has('user')): ?>
                    <form action="/add_to_cart" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value=<?php echo e($product['id']); ?>>
                    <button class="btn btn-primary">Add to cart</button>
                </form>
                    <br>
                    <form action="/add_to_cart" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value=<?php echo e($product['id']); ?>>
                    <button class="btn btn-success">Buy Now</button>
                </form>
                    <br>
            <?php else: ?>
                    <a href="/">
                    <button class="btn btn-primary">Add to cart</button>
                </a>
                <br>
                <br>
                    <a href="/">
                    <button class="btn btn-success">Buy Now</button></a><br><br>
            <?php endif; ?>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/detail.blade.php ENDPATH**/ ?>