<?php
use App\Http\Controllers\ProductController;
?>

<div class="card">
    <div class="card-header">
      Online Ice-Cream Store
    </div>
    <div class="card-body">
      <h5 class="card-title">Our Help Lines</h5>
        <a href="/aboutus" class="btn btn-primary">About us</a><br><br>
        <a href="/contactus" class="btn btn-primary">Contact us</a><br><br>
        <a href="https://github.com/Dhruv54" class="btn btn-primary">Git Hub</a><br><br>
    </div>
  </div>